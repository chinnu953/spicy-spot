let adminKey = sessionStorage.getItem("spicyAdminKey") || "";
let orders = [];
let firstLoad = true;
let lastKnownNewestId = null;

const statuses = ["New","Accepted","Preparing","Out for Delivery","Delivered","Cancelled"];

function login(){
  const key = document.getElementById("adminKey").value.trim();
  if(!key) return;
  adminKey = key;
  sessionStorage.setItem("spicyAdminKey", adminKey);
  loadOrders().catch(() => {
    document.getElementById("loginError").textContent = "Invalid password or server unavailable.";
    sessionStorage.removeItem("spicyAdminKey");
    adminKey = "";
  });
}

function logout(){
  sessionStorage.removeItem("spicyAdminKey");
  adminKey = "";
  location.reload();
}

async function loadOrders(manual=false){
  const response = await fetch("/api/orders", {
    headers: {"x-admin-key": adminKey}
  });
  if(response.status === 401) throw new Error("Unauthorized");
  if(!response.ok) throw new Error("Could not load orders");
  const data = await response.json();

  if(!firstLoad && data.length && data[0].orderId !== lastKnownNewestId){
    const newest = data[0];
    showNewOrderMessage(newest);
    beep();
  }
  if(data.length) lastKnownNewestId = data[0].orderId;
  firstLoad = false;

  orders = data;
  showDashboard();
  renderOrders();
  if(manual) showNewOrderMessage(null, "Orders refreshed.");
}

function showDashboard(){
  document.getElementById("loginPage").style.display = "none";
  document.getElementById("dashboardPage").style.display = "block";
}

function renderOrders(){
  const newCount = orders.filter(o=>o.status==="New").length;
  const preparingCount = orders.filter(o=>o.status==="Preparing").length;
  const deliveredCount = orders.filter(o=>o.status==="Delivered").length;

  document.getElementById("allCount").textContent = orders.length;
  document.getElementById("newCount").textContent = newCount;
  document.getElementById("preparingCount").textContent = preparingCount;
  document.getElementById("deliveredCount").textContent = deliveredCount;

  const box = document.getElementById("orders");
  if(!orders.length){
    box.innerHTML = `<div class="empty">No customer orders yet. Keep this page open — new orders will appear automatically.</div>`;
    return;
  }

  box.innerHTML = orders.map(order => `
    <article class="order-card">
      <div class="order-head">
        <div>
          <div class="order-id">${order.orderId}</div>
          <b>${escapeHtml(order.name)}</b>
        </div>
        <span class="badge">${escapeHtml(order.status)}</span>
      </div>

      <div class="order-info">
        <div>📞 <b>Phone:</b> ${escapeHtml(order.phone)}</div>
        <div>🏠 <b>Room/Classroom:</b> ${escapeHtml(order.room)}</div>
        <div>🕒 <b>Time:</b> ${new Date(order.createdAt).toLocaleString()}</div>
      </div>

      <div class="items">
        🍽️ ${order.items.map(i => `${escapeHtml(i.name)} × ${i.qty} — ₹${i.price*i.qty}`).join("<br>")}
        <div class="total">Total: ₹${order.total}</div>
      </div>

      <div class="status-row">
        <label><b>Change status:</b></label>
        <select id="status-${order.orderId}">
          ${statuses.map(s => `<option ${s===order.status?"selected":""}>${s}</option>`).join("")}
        </select>
        <button onclick="updateStatus('${order.orderId}')">Update</button>
      </div>
    </article>
  `).join("");
}

async function updateStatus(orderId){
  const status = document.getElementById(`status-${orderId}`).value;
  const response = await fetch(`/api/orders/${encodeURIComponent(orderId)}/status`, {
    method:"PATCH",
    headers:{
      "Content-Type":"application/json",
      "x-admin-key":adminKey
    },
    body:JSON.stringify({status})
  });
  const data = await response.json();
  if(!response.ok) return alert(data.message || "Could not update status.");
  await loadOrders();
}

function showNewOrderMessage(order, customText){
  const box = document.getElementById("newOrderMessage");
  box.style.display = "block";
  if(customText){
    document.getElementById("newOrderText").textContent = customText;
  }else if(order){
    document.getElementById("newOrderText").textContent =
      `${order.orderId} from ${order.name} — ₹${order.total}.`;
  }
  setTimeout(()=>box.style.display="none", 8000);
}

function beep(){
  try{
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if(!Ctx) return;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.frequency.value = 880;
    gain.gain.value = 0.08;
    osc.start();
    osc.stop(ctx.currentTime + 0.25);
  }catch(e){}
}

function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

if(adminKey){
  loadOrders().catch(()=>{
    sessionStorage.removeItem("spicyAdminKey");
    adminKey = "";
  });
}

// Check for new customer orders every 5 seconds while admin dashboard is open.
setInterval(()=>{
  if(adminKey) loadOrders().catch(()=>{});
}, 5000);

async function loadHistory(){
  try{
    const response = await fetch("/api/history", {headers:{"x-admin-key":adminKey}});
    const data = await response.json();
    if(!response.ok) throw new Error(data.message || "Could not load history.");
    const panel = document.getElementById("historyPanel");
    const box = document.getElementById("historyOrders");
    panel.style.display = "block";
    if(!data.length){
      box.innerHTML = '<div class="empty">No archived orders yet.</div>';
      return;
    }
    box.innerHTML = data.map(order => `
      <article class="order-card history-card">
        <div class="order-head">
          <div><div class="order-id">${escapeHtml(order.orderId)}</div><b>${escapeHtml(order.name)}</b></div>
          <span class="badge">${escapeHtml(order.status)}</span>
        </div>
        <div class="order-info">
          <div>📞 <b>Phone:</b> ${escapeHtml(order.phone)}</div>
          <div>🏠 <b>Room/Classroom:</b> ${escapeHtml(order.room)}</div>
          <div>🕒 <b>Ordered:</b> ${new Date(order.createdAt).toLocaleString()}</div>
        </div>
        <div class="items">
          🍽️ ${order.items.map(i => `${escapeHtml(i.name)} × ${i.qty} — ₹${i.price*i.qty}`).join("<br>")}
          <div class="total">Total: ₹${order.total}</div>
        </div>
      </article>`).join("");
  }catch(err){ alert(err.message); }
}

async function closeDay(){
  if(!confirm("End today's service and move ALL today's active orders to History? They will NOT be deleted.")) return;
  try{
    const response = await fetch("/api/admin/close-day", {
      method:"POST",
      headers:{"x-admin-key":adminKey}
    });
    const data = await response.json();
    if(!response.ok) throw new Error(data.message || "Could not close day.");
    alert(`Day completed. ${data.count} order(s) moved to History.`);
    await loadOrders();
    await loadHistory();
  }catch(err){ alert(err.message); }
}
