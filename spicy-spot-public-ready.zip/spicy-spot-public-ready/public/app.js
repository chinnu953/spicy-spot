let cart = JSON.parse(localStorage.getItem("spicyCart") || "[]");

function saveCart(){
  localStorage.setItem("spicyCart", JSON.stringify(cart));
}

function addToCart(name, price){
  const item = cart.find(x => x.name === name);
  if(item) item.qty++;
  else cart.push({name, price, qty:1});
  saveCart();
  updateCartBar();
  showToast(`${name} added to cart`);
}

function cartTotal(){
  return cart.reduce((sum,x)=>sum + x.price*x.qty, 0);
}

function updateCartBar(){
  const count = cart.reduce((sum,x)=>sum+x.qty,0);
  const bar = document.getElementById("cartBar");
  bar.style.display = count ? "flex" : "none";
  document.getElementById("cartSummary").textContent = `${count} item${count>1?"s":""} • ₹${cartTotal()}`;
}

function openCart(){
  renderCart();
  document.getElementById("cartModal").style.display = "flex";
}

function renderCart(){
  const box = document.getElementById("cartItems");
  box.innerHTML = cart.length
    ? cart.map(x => `<div class="orderline"><span>${x.name} × ${x.qty}</span><b>₹${x.price*x.qty}</b></div>`).join("")
    : `<div class="empty">Your cart is empty.</div>`;
  document.getElementById("cartTotal").textContent = cart.length ? `Total: ₹${cartTotal()}` : "";
}

function openCheckout(){
  if(!cart.length) return showToast("Please add an item first.");
  closeModal("cartModal");
  document.getElementById("checkoutModal").style.display = "flex";
}

function closeModal(id){
  document.getElementById(id).style.display = "none";
}

async function placeOrder(){
  const name = document.getElementById("customerName").value.trim();
  const phone = document.getElementById("customerPhone").value.trim();
  const room = document.getElementById("customerRoom").value.trim();

  if(!name || !phone || !room) return showToast("Please fill all delivery details.");
  if(!/^\d{10}$/.test(phone)) return showToast("Enter a valid 10-digit phone number.");

  const btn = document.querySelector("#checkoutModal .full-btn");
  btn.disabled = true;
  btn.textContent = "Placing Order...";

  try{
    const response = await fetch("/api/orders", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({name, phone, room, items:cart})
    });
    const data = await response.json();
    if(!response.ok) throw new Error(data.message || "Order failed");

    cart = [];
    saveCart();
    updateCartBar();
    closeModal("checkoutModal");

    document.getElementById("newOrderId").textContent = data.order.orderId;
    document.getElementById("successModal").style.display = "flex";

    document.getElementById("customerName").value = "";
    document.getElementById("customerPhone").value = "";
    document.getElementById("customerRoom").value = "";
  }catch(err){
    showToast(err.message || "Could not place order.");
  }finally{
    btn.disabled = false;
    btn.textContent = "Confirm & Place Order";
  }
}

async function trackOrder(){
  const id = document.getElementById("trackId").value.trim();
  const result = document.getElementById("trackResult");
  if(!id) return showToast("Enter your Order ID.");

  result.innerHTML = `<div class="track-card">Checking order...</div>`;
  try{
    const response = await fetch(`/api/orders/${encodeURIComponent(id)}`);
    const data = await response.json();
    if(!response.ok) throw new Error(data.message || "Order not found.");

    result.innerHTML = `
      <div class="track-card">
        <b>${data.orderId}</b>
        <div class="status">${data.status}</div>
        <div><b>${data.name}</b> • Room ${data.room}</div>
        <div>${data.items.map(x => `${x.name} × ${x.qty}`).join("<br>")}</div>
        <div style="margin-top:8px"><b>Total: ₹${data.total}</b></div>
      </div>`;
  }catch(err){
    result.innerHTML = `<div class="track-card">${err.message}</div>`;
  }
}

function showToast(message){
  const t = document.getElementById("toast");
  t.textContent = message;
  t.style.display = "block";
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => t.style.display = "none", 3000);
}

updateCartBar();
